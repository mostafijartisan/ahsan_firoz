# QA Checklist

- [x] Navigation labels exactly: Home, About, Skills, Experience, Contact
- [x] Responsive navigation drawer
- [x] Light palette with #39BF47 signature green
- [x] No invented project photographs
- [x] Profile facts sourced from supplied PDF
- [x] Project list link points to supplied project PDF
- [x] Resume link points to supplied resume PDF
- [x] Scroll reveal with reduced-motion fallback
- [x] Active navigation state updates on scroll
- [x] Responsive grids for desktop/tablet/mobile
- [x] Keyboard-accessible nav button and links
- [x] Semantic section headings and image alt text
- [ ] Final browser/device visual QA after stakeholder review
- [ ] Production email/contact endpoint configuration
