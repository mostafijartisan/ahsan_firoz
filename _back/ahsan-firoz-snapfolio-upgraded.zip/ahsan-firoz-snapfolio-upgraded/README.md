# Ahsan Firoz — SnapFolio-inspired Portfolio Upgrade

A light, premium, architecture-oriented one-page portfolio UI inspired by the supplied SnapFolio reference, rebuilt around Ahsan Firoz's brand palette and profile PDF.

## Navigation
Home · About · Skills · Experience · Contact

## Stack
- Bootstrap 5 CSS/grid and Bootstrap Icons
- Tailwind CSS CDN utilities/config (preflight disabled to avoid conflicts with Bootstrap)
- Vanilla JavaScript
- AOS scroll animation
- CSS architectural grid/datum system

## Content source
Profile and project facts are based on the supplied Ahsan Firoz profile and project PDFs. Unsupported project metrics/claims are intentionally not invented.

## Run
Open `index.html` in a modern browser. For local development, a static server is recommended.

## Assets
`assets/img/ahsan-portrait.png` is the supplied professional portrait. Project visuals are intentionally represented through branded architectural UI tiles rather than misattributed stock photography.
